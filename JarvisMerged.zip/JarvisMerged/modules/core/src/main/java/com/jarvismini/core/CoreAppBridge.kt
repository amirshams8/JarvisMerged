package com.jarvismini.core
object CoreAppBridge { fun appName() = "JarvisMerged" }
