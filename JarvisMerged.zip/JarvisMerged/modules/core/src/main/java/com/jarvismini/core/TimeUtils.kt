package com.jarvismini.core
object TimeUtils { fun nowMs() = System.currentTimeMillis() }
