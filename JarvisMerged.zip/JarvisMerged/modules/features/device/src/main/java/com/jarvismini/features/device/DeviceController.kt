package com.jarvismini.features.device
object DeviceController { fun info() = "DeviceController placeholder" }
