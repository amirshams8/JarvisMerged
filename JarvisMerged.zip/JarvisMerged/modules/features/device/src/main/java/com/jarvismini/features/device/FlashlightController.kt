package com.jarvismini.features.device
object FlashlightController { fun info() = "FlashlightController placeholder" }
