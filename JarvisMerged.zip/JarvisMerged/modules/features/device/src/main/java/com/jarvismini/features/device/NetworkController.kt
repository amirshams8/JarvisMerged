package com.jarvismini.features.device
object NetworkController { fun info() = "NetworkController placeholder" }
