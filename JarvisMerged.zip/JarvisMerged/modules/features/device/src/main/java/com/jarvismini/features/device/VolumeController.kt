package com.jarvismini.features.device
object VolumeController { fun info() = "VolumeController placeholder" }
