package com.jarvismini.features.media
object MediaController { fun info() = "MediaController placeholder" }
