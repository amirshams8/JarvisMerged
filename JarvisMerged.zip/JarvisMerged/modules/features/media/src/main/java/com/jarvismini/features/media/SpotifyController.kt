package com.jarvismini.features.media
object SpotifyController { fun info() = "SpotifyController placeholder" }
