package com.jarvismini.features.media
object YTMusicController { fun info() = "YTMusicController placeholder" }
