package com.jarvismini.features.monitoring
object MonitoringEvent { fun info() = "MonitoringEvent placeholder" }
