package com.jarvismini.features.monitoring
object SleepReportGenerator { fun info() = "SleepReportGenerator placeholder" }
