package com.jarvismini.features.monitoring
object SystemHealthMonitor { fun info() = "SystemHealthMonitor placeholder" }
