package com.jarvismini.features.vision
object AiCameraAssist { fun info() = "AiCameraAssist placeholder" }
