package com.jarvismini.features.vision
object AiScreenAssist { fun info() = "AiScreenAssist placeholder" }
