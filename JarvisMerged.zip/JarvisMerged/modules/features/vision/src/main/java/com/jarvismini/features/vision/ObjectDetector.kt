package com.jarvismini.features.vision
object ObjectDetector { fun info() = "ObjectDetector placeholder" }
