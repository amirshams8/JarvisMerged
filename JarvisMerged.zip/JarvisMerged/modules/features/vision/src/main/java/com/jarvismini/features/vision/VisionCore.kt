package com.jarvismini.features.vision
object VisionCore { fun info() = "VisionCore placeholder" }
